/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function set_panic_hook(): void;
export function set_log_level(a: number, b: number): void;
export function did_resolve(a: number, b: number, c: number): number;
export function did_create(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function did_update(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function execute_vade(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number): number;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h6534dd2f6be3d34a(a: number, b: number, c: number): void;
export function __wbindgen_free(a: number, b: number): void;
export function __wbindgen_exn_store(a: number): void;
export function wasm_bindgen__convert__closures__invoke2_mut__h568371bf6c6d248a(a: number, b: number, c: number, d: number): void;
