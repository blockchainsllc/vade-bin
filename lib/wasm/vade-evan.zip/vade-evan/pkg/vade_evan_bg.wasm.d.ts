/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function set_panic_hook(): void;
export function set_log_level(a: number, b: number): void;
export function did_resolve(a: number, b: number, c: number): number;
export function did_create(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function did_update(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function run_custom_function(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number): number;
export function vc_zkp_create_credential_offer(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_create_credential_proposal(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_create_credential_schema(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_create_revocation_registry_definition(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_update_revocation_registry(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_issue_credential(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_finish_credential(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_present_proof(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_request_credential(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_request_proof(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_revoke_credential(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function vc_zkp_verify_proof(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function execute_vade(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number): number;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h691b83de3d4cd48f(a: number, b: number, c: number): void;
export function __wbindgen_free(a: number, b: number): void;
export function __wbindgen_exn_store(a: number): void;
export function wasm_bindgen__convert__closures__invoke2_mut__h07d540e49cfe2c2f(a: number, b: number, c: number, d: number): void;
