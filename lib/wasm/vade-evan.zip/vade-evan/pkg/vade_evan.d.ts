/* tslint:disable */
/* eslint-disable */
/**
*/
export function set_panic_hook(): void;
/**
* @param {string} log_level
*/
export function set_log_level(log_level: string): void;
/**
* @param {string} did_or_method
* @param {string} custom_func_name
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function run_custom_function(did_or_method: string, custom_func_name: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_create_credential_offer(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_create_credential_proposal(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_create_credential_schema(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_create_revocation_registry_definition(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_update_revocation_registry(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_issue_credential(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_finish_credential(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_present_proof(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_request_credential(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_request_proof(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_revoke_credential(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function vc_zkp_verify_proof(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} func_name
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {string} custom_func_name
* @param {any} config
* @returns {any}
*/
export function execute_vade(func_name: string, did_or_method: string, options: string, payload: string, custom_func_name: string, config: any): any;
/**
* Indicates the status returned from `PoKOfSignatureProof`
*/
export enum PoKOfSignatureProofStatus {
/**
* The proof verified
*/
  Success,
/**
* The proof failed because the signature proof of knowledge failed
*/
  BadSignature,
/**
* The proof failed because a hidden message was invalid when the proof was created
*/
  BadHiddenMessage,
/**
* The proof failed because a revealed message was invalid
*/
  BadRevealedMessage,
}
