/* tslint:disable */
/* eslint-disable */
/**
*/
export function set_panic_hook(): void;
/**
* @param {string} log_level
*/
export function set_log_level(log_level: string): void;
/**
* @param {string} did_or_method
* @param {any} config
* @returns {any}
*/
export function did_resolve(did_or_method: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function did_create(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {any} config
* @returns {any}
*/
export function did_update(did_or_method: string, options: string, payload: string, config: any): any;
/**
* @param {string} func_name
* @param {string} did_or_method
* @param {string} options
* @param {string} payload
* @param {string} custom_func_name
* @param {any} config
* @returns {any}
*/
export function execute_vade(func_name: string, did_or_method: string, options: string, payload: string, custom_func_name: string, config: any): any;
